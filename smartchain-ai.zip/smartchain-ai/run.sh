#!/usr/bin/env bash
# One-command start: installs dependencies, trains models on first run, serves API + dashboard.
set -e
cd "$(dirname "$0")"
python3 -m pip install -q -r requirements.txt
cd backend
echo "Starting SmartChain AI on http://localhost:8000  (API docs: /docs)"
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
