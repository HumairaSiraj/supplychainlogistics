# SmartChain AI: Delay-Aware Supply Chain Optimizer

An end-to-end system for **AI-Powered Supply Chain and Logistics Optimization**. It predicts shipment delays
(traffic, weather, port congestion), forecasts warehouse demand, and recommends routes and inventory levels that
stay reliable **when travel times are uncertain**.

```
 conditions (weather, traffic, port congestion)         demand history
              |                                               |
              v                                               v
  +---------------------------------------------------------------------+
  | PART 1  AI prediction   XGBoost: P(late), P50 delay, P90 delay,     |
  |                         14-day demand forecast                      |
  +---------------------------------+-----------------------------------+
                                    | delay distribution per leg
                                    v
  +---------------------------------------------------------------------+
  | PART 2  Optimization    OR-Tools multi-depot VRP with deadlines,    |
  |                         risk-aware travel times, auto re-routing,   |
  |                         reorder point + safety stock, FastAPI      |
  +---------------------------------+-----------------------------------+
                                    | JSON APIs
                                    v
  +---------------------------------------------------------------------+
  | PART 3  Dashboard       Leaflet map coloured by late risk, KPIs,    |
  |                         what-if simulator, inventory alerts         |
  +---------------------------------------------------------------------+
```

## Run it (about 1 minute)

Needs Python 3.10+ and an internet connection for the map tiles (CDN).

```bash
# macOS / Linux
./run.sh

# Windows
run.bat

# or manually
cd backend
pip install -r ../requirements.txt
uvicorn app.main:app --port 8000
```

Open **http://localhost:8000** (dashboard) or **http://localhost:8000/docs** (interactive API docs).
On the first start the models train automatically (a few seconds) and are saved in `backend/models/`.

## What to try in the dashboard

1. Compare **SmartChain plan** and **Free-flow baseline** (the toggle above the map).
2. Click **Storm at Chennai Port**. The system predicts the delay impact, shows what happens to the old plan,
   re-optimizes automatically, and raises the Chennai inventory alert.
3. Move the **Demand level** slider to see capacity-driven re-planning.
4. **Reset conditions** to start over.

## How it handles uncertain travel times (the key challenge)

* The delay model predicts a **distribution**, not a single number: P(late), median delay (P50) and 90th-percentile
  delay (P90) from XGBoost quantile regression. Measured P90 coverage is about 89.5% against a 90% target.
* The optimizer plans with `free-flow time + P50 + 0.5 * (P90 - P50)`, so risky links look longer. It avoids them or
  serves tight-deadline stops first.
* Every plan is scored the same way: a Monte-Carlo simulation (1,500 draws) samples random delays for each leg and
  reports the probability that each stop meets its deadline.
* Inventory safety stock uses the spread of the predicted lead time, so a storm raises the reorder point automatically.

## API

| Endpoint | Purpose |
|---|---|
| `POST /predict/delay` | P(late), P50/P90 delay for one leg (`{"origin":"W1","destination":"C04"}`) |
| `GET /predict/demand?warehouse=W1&days=14` | Demand history + forecast |
| `POST /optimize/routes` | Optimized plan (`mode`: `smart` or `baseline`, `demand_scale`) |
| `POST /optimize/compare` | Baseline vs SmartChain under current conditions |
| `GET /inventory/recommend` | Reorder point, safety stock, order quantity, alerts |
| `POST /simulate/disruption` | Inject storm / port congestion / traffic, then re-plan |
| `POST /simulate/reset` | Back to normal conditions |
| `GET /api/metrics`, `/api/network`, `/api/state` | Model metrics, network, current conditions |

## Project structure

```
smartchain-ai/
  backend/app/
    common.py        constants, shared feature helpers
    network.py       ports, warehouses, delivery points
    conditions.py    live weather / traffic / port state + disruption injection     (Part 1)
    data_gen.py      synthetic shipment + demand data                               (Part 1)
    train.py         trains delay classifier, P50/P90 models, demand model          (Part 1)
    forecasting.py   demand features + recursive forecast                           (Part 1)
    predictor.py     prediction layer, all-pairs delay matrix                       (Part 1)
    optimizer.py     OR-Tools VRP, Monte-Carlo scoring, comparison                  (Part 2)
    inventory.py     reorder point, safety stock, alerts                            (Part 2)
    main.py          FastAPI endpoints                                              (Part 2)
  frontend/          index.html, style.css, app.js (Leaflet map, no build step)     (Part 3)
  docs/TEAM_SPLIT.md who explains what, 3-minute demo script, judge Q&A
```

## Honest notes and limitations

* **Training data is synthetic.** `data_gen.py` reproduces the relationships seen in the public datasets (delay grows
  with distance, bad weather, congested ports and peak-hour traffic; spread grows in bad conditions) so the project
  runs anywhere. To use real data (DataCo Smart Supply Chain, BTS Freight Analysis Framework, World Bank LPI),
  build a DataFrame with the columns in `common.DELAY_FEATURES` plus `delay_hours` and call
  `train.train_all(your_df)`.
* **Weather, traffic and port congestion are simulated state** (`conditions.py`). In production, feed them from
  Open-Meteo, a traffic API and port data.
* **Improvements are measured in simulation** against the learned delay model, not on real deliveries.
  Quote them as simulated results.
* Per-leg delays are sampled independently in the Monte-Carlo scoring, and the port dwell time in
  `inventory.py` is a simple documented heuristic.
* Distances use straight-line x 1.25. Swap in OSRM or Google Distance Matrix for real road distances.
* Data is stored in CSV files. Moving it to PostgreSQL is a straightforward next step.
