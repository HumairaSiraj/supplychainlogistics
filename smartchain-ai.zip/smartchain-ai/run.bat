@echo off
rem One-command start for Windows: installs dependencies, trains models on first run, serves API + dashboard.
cd /d "%~dp0"
python -m pip install -q -r requirements.txt
cd backend
echo Starting SmartChain AI on http://localhost:8000  (API docs: /docs)
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
