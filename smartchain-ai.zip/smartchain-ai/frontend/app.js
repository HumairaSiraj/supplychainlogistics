/* SmartChain AI dashboard - plain JavaScript + Leaflet, no build step. */
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const COLORS = { low: '#15803d', medium: '#d97706', high: '#dc2626' };
const FEATURE_LABELS = {
  planned_hours: 'Planned travel time', weather: 'Weather severity', distance_km: 'Distance',
  port_congestion: 'Port congestion', mode: 'Transport mode', traffic: 'Traffic',
  month: 'Month / season', hour: 'Hour of day', dow: 'Day of week',
};
const STATUS_LABEL = { ok: 'OK', watch: 'Watch', reorder: 'Reorder', critical: 'Critical' };

const S = {
  net: null, nodeById: {}, plans: { smart: null, baseline: null }, view: 'smart',
  improvement: null, inventory: null, scale: 1.0, state: null, busy: false,
};
let map, routeLayer, nodeLayer, eventLayer;

/* ------------------------------------------------------------------ helpers */
async function api(path, body) {
  const opts = body === undefined ? undefined
    : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
  const res = await fetch(path, opts);
  if (!res.ok) {
    let msg = res.statusText;
    try { const j = await res.json(); msg = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail); } catch (e) { /* ignore */ }
    throw new Error(msg);
  }
  return res.json();
}
function fmtH(h) {
  const m = Math.max(0, Math.round(h * 60));
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
}
const pct = (x) => `${Math.round(x * 100)}%`;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => { t.hidden = true; }, 6000);
}
function setBusy(on, text) {
  S.busy = on;
  $('#busy').hidden = !on;
  if (text) $('#busyText').textContent = text;
  document.querySelectorAll('button').forEach((b) => { b.disabled = on; });
}
async function guarded(text, fn) {
  setBusy(true, text);
  try { await fn(); } catch (e) { toast(`Something went wrong: ${e.message}`); } finally { setBusy(false); }
}

/* ------------------------------------------------------------------ map */
function initMap() {
  map = L.map('map', { zoomControl: true, scrollWheelZoom: false }).setView([14.2, 79.0], 6);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap contributors &copy; CARTO', maxZoom: 12,
  }).addTo(map);
  eventLayer = L.layerGroup().addTo(map);
  routeLayer = L.layerGroup().addTo(map);
  nodeLayer = L.layerGroup().addTo(map);
  const pts = S.net.nodes.map((n) => [n.lat, n.lon]);
  map.fitBounds(pts, { padding: [30, 30] });
}

function nodeIcon(n) {
  if (n.kind === 'warehouse') {
    return L.divIcon({ className: '', iconSize: [20, 20], iconAnchor: [10, 10],
      html: '<div class="node-icon" style="width:20px;height:20px;background:#0f2742"></div>' });
  }
  return L.divIcon({ className: '', iconSize: [18, 18], iconAnchor: [9, 9],
    html: '<div class="node-icon" style="width:14px;height:14px;margin:2px;background:#2563eb;transform:rotate(45deg)"></div>' });
}

function renderMap() {
  routeLayer.clearLayers(); nodeLayer.clearLayers(); eventLayer.clearLayers();
  const plan = S.plans[S.view];

  (S.state?.events || []).forEach((e) => {
    const color = e.kind === 'storm' ? '#dc2626' : '#f59e0b';
    L.circle([e.lat, e.lon], { radius: e.radius_km * 1000, color, weight: 1, fillColor: color, fillOpacity: 0.12 })
      .bindTooltip(`${e.kind.replace('_', ' ')} at ${esc(e.target_name)} (severity ${e.severity.toFixed(2)})`)
      .addTo(eventLayer);
  });

  const stopRisk = {};
  if (plan) {
    plan.routes.forEach((r) => {
      r.stops.forEach((s) => {
        stopRisk[s.id] = s.risk;
        const a = S.nodeById[s.from], b = S.nodeById[s.id];
        const line = L.polyline([[a.lat, a.lon], [b.lat, b.lon]], {
          color: COLORS[s.risk], weight: 4, opacity: 0.9, dashArray: s.risk === 'high' ? '8 6' : null,
        });
        line.bindTooltip(
          `<b>${esc(r.vehicle)}</b> ${esc(s.from_name)} &rarr; ${esc(s.name)}<br>` +
          `ETA ${fmtH(s.eta_p50_h)} (P90 ${fmtH(s.eta_p90_h)}), deadline ${fmtH(s.deadline_h)}<br>` +
          `On-time probability ${pct(s.on_time_prob)}`, { sticky: true });
        line.addTo(routeLayer);
      });
    });
  }

  S.net.nodes.forEach((n) => {
    if (n.kind === 'customer') {
      const risk = stopRisk[n.id];
      L.circleMarker([n.lat, n.lon], {
        radius: 8, weight: 2, color: '#fff', fillOpacity: 1, fillColor: risk ? COLORS[risk] : '#94a3b8',
      }).bindTooltip(`${esc(n.name)}: ${n.demand} units, deadline ${fmtH(n.deadline_h)}`).addTo(nodeLayer);
    } else {
      L.marker([n.lat, n.lon], { icon: nodeIcon(n), keyboard: false })
        .bindTooltip(`${esc(n.name)} (${n.kind})`).addTo(nodeLayer);
    }
  });
}

/* ------------------------------------------------------------------ KPIs */
function renderKpis() {
  const plan = S.plans[S.view];
  if (!plan) { $('#kpis').innerHTML = ''; return; }
  const k = plan.kpis, imp = S.view === 'smart' ? S.improvement : null;
  const atRisk = S.inventory ? S.inventory.at_risk : 0;
  const sgn = (v) => (v > 0 ? '+' : '');
  const cards = [
    { label: 'On-time deliveries', value: `${k.on_time_pct}<small>%</small>`,
      delta: imp ? `${sgn(imp.on_time_pct_points)}${imp.on_time_pct_points} pts vs baseline` : 'Probability-weighted',
      cls: imp ? (imp.on_time_pct_points > 0 ? 'good' : '') : '' },
    { label: 'Avg lateness per stop', value: `${k.avg_late_hours}<small> h</small>`,
      delta: imp ? `${imp.late_hours_reduction_pct}% less than baseline` : `${k.at_risk_stops} stops at risk`,
      cls: imp && imp.late_hours_reduction_pct > 0 ? 'good' : '' },
    { label: 'Total distance', value: `${Math.round(k.total_km).toLocaleString()}<small> km</small>`,
      delta: imp ? `${sgn(imp.distance_change_pct)}${imp.distance_change_pct}% vs baseline` : `${k.vehicles_used} vehicles`, cls: '' },
    { label: 'Warehouses needing stock action', value: `${atRisk}<small> / 3</small>`,
      delta: atRisk ? 'See inventory alerts' : 'All stocked', cls: atRisk ? 'bad' : 'good' },
  ];
  $('#kpis').innerHTML = cards.map((c) =>
    `<div class="kpi"><div class="label">${c.label}</div><div class="value">${c.value}</div>` +
    `<div class="delta ${c.cls}">${esc(c.delta)}</div></div>`).join('');
}

/* ------------------------------------------------------------------ tables */
function renderShipments() {
  const plan = S.plans[S.view];
  const tbl = $('#shipTable');
  if (!plan) { tbl.innerHTML = ''; return; }
  let rows = [];
  plan.routes.forEach((r) => r.stops.forEach((s) => rows.push({ r, s })));
  if ($('#riskOnly').checked) rows = rows.filter((x) => x.s.risk !== 'low');
  rows.sort((a, b) => b.s.late_risk - a.s.late_risk);
  tbl.innerHTML =
    '<thead><tr><th>Vehicle</th><th>Leg</th><th class="num">Units</th><th class="num">ETA (median)</th>' +
    '<th class="num">ETA (P90)</th><th class="num">Deadline</th><th class="num">Leg delay prob.</th>' +
    '<th class="num">Late risk</th><th>Risk</th></tr></thead><tbody>' +
    rows.map(({ r, s }) =>
      `<tr><td>${esc(r.vehicle)}</td><td>${esc(s.from_name)} &rarr; <b>${esc(s.name)}</b></td>` +
      `<td class="num">${s.units}</td><td class="num">${fmtH(s.eta_p50_h)}</td><td class="num">${fmtH(s.eta_p90_h)}</td>` +
      `<td class="num">${fmtH(s.deadline_h)}</td><td class="num">${pct(s.leg_prob_late)}</td>` +
      `<td class="num">${pct(s.late_risk)}</td><td><span class="badge ${s.risk}">${s.risk}</span></td></tr>`).join('') +
    '</tbody>';
  if (!rows.length) tbl.innerHTML = '<tbody><tr><td>No at-risk shipments.</td></tr></tbody>';
}

function renderInventory() {
  const inv = S.inventory;
  if (!inv) return;
  const alerts = inv.items.filter((i) => i.status === 'critical' || i.status === 'reorder' || i.status === 'watch');
  $('#invAlerts').innerHTML = alerts.length
    ? alerts.map((i) => {
        const when = i.stockout_in_days ? `forecast stock-out in ~${i.stockout_in_days} days` : `${i.days_of_cover} days of cover`;
        const qty = i.recommended_order_qty.toLocaleString();
        const act = i.status === 'watch'
          ? `Approaching the reorder point; plan an order of ${qty} units.`
          : `Order ${qty} units now.`;
        return `<div class="alert ${i.status}"><b>${esc(i.name)}</b>: ${when}; inbound lead time up to ` +
               `${i.lead_time_p90_days} days (port congestion ${pct(i.port_congestion)}). ${act}</div>`;
      }).join('')
    : '<div class="alert none">All warehouses have enough stock for the predicted lead times.</div>';
  $('#invTable').innerHTML =
    '<thead><tr><th>Warehouse</th><th class="num">Stock</th><th class="num">Demand/day</th><th class="num">Cover (days)</th>' +
    '<th class="num">Lead time P50/P90 (d)</th><th class="num">Safety stock</th><th class="num">Reorder pt</th>' +
    '<th class="num">Order qty</th><th>Status</th></tr></thead><tbody>' +
    inv.items.map((i) =>
      `<tr><td>${esc(i.name)}</td><td class="num">${i.stock.toLocaleString()}</td><td class="num">${Math.round(i.avg_daily_demand)}</td>` +
      `<td class="num">${i.days_of_cover}</td><td class="num">${i.lead_time_days} / ${i.lead_time_p90_days}</td>` +
      `<td class="num">${i.safety_stock.toLocaleString()}</td><td class="num">${i.reorder_point.toLocaleString()}</td>` +
      `<td class="num">${i.recommended_order_qty ? i.recommended_order_qty.toLocaleString() : '-'}</td>` +
      `<td><span class="badge ${i.status}">${STATUS_LABEL[i.status]}</span></td></tr>`).join('') + '</tbody>';
}

/* ------------------------------------------------------------------ demand chart */
async function renderForecast() {
  const wh = $('#fcWh').value;
  const d = await api(`/predict/demand?warehouse=${wh}&days=14`);
  const hist = d.history.map((x) => x.units), fc = d.forecast.map((x) => x.units);
  const all = hist.concat(fc), W = 560, H = 190, P = { l: 40, r: 10, t: 10, b: 24 };
  const lo = Math.min(...all) * 0.9, hi = Math.max(...all) * 1.05;
  const x = (i) => P.l + (i / (all.length - 1)) * (W - P.l - P.r);
  const y = (v) => H - P.b - ((v - lo) / (hi - lo)) * (H - P.t - P.b);
  const path = (arr, off) => arr.map((v, i) => `${i ? 'L' : 'M'}${x(i + off).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const joined = [hist[hist.length - 1]].concat(fc);
  const ticks = [lo, (lo + hi) / 2, hi].map((v) =>
    `<text x="${P.l - 6}" y="${y(v) + 4}" text-anchor="end" font-size="11" fill="#5d6b7e">${Math.round(v)}</text>` +
    `<line x1="${P.l}" x2="${W - P.r}" y1="${y(v)}" y2="${y(v)}" stroke="#e2e7ef"/>`).join('');
  $('#fcChart').innerHTML =
    `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Demand history and 14 day forecast for ${esc(wh)}">` +
    `${ticks}<path d="${path(hist, 0)}" fill="none" stroke="#1d4ed8" stroke-width="2"/>` +
    `<path d="${path(joined, hist.length - 1)}" fill="none" stroke="#1d4ed8" stroke-width="2" stroke-dasharray="6 4"/>` +
    `<line x1="${x(hist.length - 1)}" x2="${x(hist.length - 1)}" y1="${P.t}" y2="${H - P.b}" stroke="#94a3b8" stroke-dasharray="2 3"/>` +
    `<text x="${x(hist.length - 1) + 6}" y="${P.t + 12}" font-size="11" fill="#5d6b7e">today</text></svg>`;
}

/* ------------------------------------------------------------------ metrics */
async function renderMetrics() {
  const m = await api('/api/metrics');
  const c = m.delay_classifier;
  const cells = [
    [c.roc_auc.toFixed(2), 'Delay classifier ROC-AUC'],
    [`${pct(c.precision)} / ${pct(c.recall)}`, 'Late-shipment precision / recall'],
    [`${m.delay_p50.mae_hours.toFixed(2)} h`, `Median-delay MAE (naive ${m.delay_p50.baseline_mae_hours.toFixed(2)} h)`],
    [pct(m.delay_p90.coverage), 'P90 delay coverage (target 90%)'],
    [`${m.demand.mape_7day_recursive_pct}%`, `Demand 7-day MAPE (naive ${m.demand.mape_naive_pct}%)`],
    [m.training_rows.toLocaleString(), 'Training shipments'],
  ];
  $('#metrics').innerHTML = '<div class="metric-grid">' +
    cells.map(([v, l]) => `<div class="metric"><b>${esc(v)}</b><span>${esc(l)}</span></div>`).join('') + '</div>';
  const imp = Object.entries(m.feature_importance), top = imp[0][1];
  $('#importance').innerHTML = imp.map(([k, v]) =>
    `<div class="imp-row"><span>${esc(FEATURE_LABELS[k] || k)}</span>` +
    `<div class="bar"><i style="width:${(v / top) * 100}%"></i></div><span>${pct(v)}</span></div>`).join('');
}

/* ------------------------------------------------------------------ what-if */
function renderStatus() {
  const n = (S.state?.events || []).length;
  const pill = $('#statusPill');
  pill.className = `pill ${n ? 'warn' : 'ok'}`;
  pill.textContent = n ? `${n} active disruption${n > 1 ? 's' : ''}` : 'Normal conditions';
}

function fillTargets() {
  const kind = $('#wiKind').value;
  const kinds = kind === 'port_congestion' ? ['port'] : (kind === 'storm' ? ['port', 'warehouse', 'customer'] : ['warehouse', 'customer']);
  $('#wiTarget').innerHTML = S.net.nodes.filter((n) => kinds.includes(n.kind))
    .map((n) => `<option value="${n.id}">${esc(n.name)}</option>`).join('');
}

function renderImpact(res) {
  const box = $('#impact');
  const rows = [
    ['Before event', res.before_kpis, '#64748b'],
    ['Old plan, no re-plan', res.no_replan_kpis, COLORS.high],
    ['SmartChain re-plan', res.after.kpis, COLORS.low],
  ];
  const e = res.event;
  box.hidden = false;
  box.innerHTML =
    `<h2>Impact: ${esc(e.kind.replace('_', ' '))} at ${esc(e.target_name)}</h2>` +
    rows.map(([l, k, c]) =>
      `<div class="impact-row"><span>${l}</span><div class="bar"><i style="width:${k.on_time_pct}%;background:${c}"></i></div>` +
      `<b>${k.on_time_pct}%</b></div>`).join('') +
    `<p class="impact-note">${res.triggered_replan ? 'Delay risk crossed the re-plan threshold, so routes were re-optimized automatically.' : 'Impact stayed below the re-plan threshold.'} ` +
    `Re-routing recovered <b>${res.recovered_points} points</b> of on-time delivery` +
    `${res.routes_changed ? ' by changing routes.' : '.'}</p>`;
}

async function runWhatIf(kind, target, severity) {
  await guarded('Predicting impact and re-routing…', async () => {
    const res = await api('/simulate/disruption', { kind, target, severity, demand_scale: S.scale });
    S.plans.smart = res.after; S.plans.baseline = res.baseline_after; S.improvement = res.improvement;
    S.state = await api('/api/state');
    S.inventory = await api('/inventory/recommend');
    renderAll(); renderImpact(res);
  });
}

/* ------------------------------------------------------------------ main flow */
function renderAll() { renderStatus(); renderMap(); renderKpis(); renderShipments(); renderInventory(); }

async function refreshAll() {
  await guarded('Optimizing routes with delay predictions…', async () => {
    const [cmp, state, inv] = await Promise.all([
      api('/optimize/compare', { demand_scale: S.scale }), api('/api/state'), api('/inventory/recommend'),
    ]);
    S.plans.smart = cmp.smart; S.plans.baseline = cmp.baseline; S.improvement = cmp.improvement;
    S.state = state; S.inventory = inv;
    renderAll();
  });
}

function setView(v) {
  S.view = v;
  $('#segSmart').classList.toggle('active', v === 'smart'); $('#segSmart').setAttribute('aria-selected', v === 'smart');
  $('#segBase').classList.toggle('active', v === 'baseline'); $('#segBase').setAttribute('aria-selected', v === 'baseline');
  renderMap(); renderKpis(); renderShipments();
}

async function init() {
  try {
    S.net = await api('/api/network');
    S.net.nodes.forEach((n) => { S.nodeById[n.id] = n; });
    initMap(); fillTargets();
    $('#fcWh').innerHTML = S.net.warehouses.map((id) => `<option value="${id}">${esc(S.nodeById[id].name)}</option>`).join('');
    $('#wiKind').addEventListener('change', fillTargets);
    $('#wiSev').addEventListener('input', (e) => { $('#wiSevOut').textContent = Number(e.target.value).toFixed(2); });
    $('#wiRun').addEventListener('click', () => runWhatIf($('#wiKind').value, $('#wiTarget').value, Number($('#wiSev').value)));
    document.querySelectorAll('.presets button').forEach((b) =>
      b.addEventListener('click', () => runWhatIf(b.dataset.kind, b.dataset.target, 0.9)));
    $('#btnReset').addEventListener('click', async () => {
      await guarded('Resetting conditions…', async () => { await api('/simulate/reset', {}); $('#impact').hidden = true; });
      await refreshAll();
    });
    $('#segSmart').addEventListener('click', () => setView('smart'));
    $('#segBase').addEventListener('click', () => setView('baseline'));
    $('#riskOnly').addEventListener('change', renderShipments);
    $('#fcWh').addEventListener('change', () => renderForecast().catch((e) => toast(e.message)));
    $('#scale').addEventListener('input', (e) => { $('#scaleOut').innerHTML = `&times;${Number(e.target.value).toFixed(2)}`; });
    $('#scale').addEventListener('change', async (e) => { S.scale = Number(e.target.value); await refreshAll(); });
    renderMetrics().catch((e) => toast(e.message));
    renderForecast().catch((e) => toast(e.message));
    await refreshAll();
  } catch (e) {
    toast(`Could not reach the API: ${e.message}`);
  }
}
init();
