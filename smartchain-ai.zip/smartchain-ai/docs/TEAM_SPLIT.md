# Team Split, Demo Script and Judge Q&A

Three members, three parts. Each part has its own files, a 60-second explanation, and a moment in the live demo.
(If you want only two speakers, merge Part 2 and Part 3.)

> The numbers below come from one test run. They can shift slightly from day to day, because the demand data and
> calendar features are tied to today's date. **Read the final numbers off your own screen before presenting.**

---

## Member 1: Data and AI Prediction ("the brain")

**Files:** `backend/app/data_gen.py`, `train.py`, `forecasting.py`, `predictor.py`, `conditions.py`

**What you built**
* A dataset of 30,000 shipment legs (distance, mode, weather, traffic, port congestion, hour, day, month) and 900 days of demand for 3 warehouses.
* **Three delay models** (XGBoost): a classifier for *"will this leg be late (> 1.5 h)?"*, a median-delay model (P50), and a 90th-percentile model (P90).
* A **demand forecaster**: XGBoost on lag features, forecasting 14 days recursively.

**Say this (about 60 seconds)**
> "Supply chains don't fail because the average trip is slow; they fail because of the bad days. So instead of one travel time,
> our model predicts a range. For every leg it gives the probability of being late, the typical delay, and the 90th-percentile delay.
> The classifier reaches ROC-AUC 0.91. The P90 model is well calibrated: 89.5% of real delays fall under its prediction, against a 90% target.
> The demand model has 6.6% error over 7 days, compared with 16.7% for a naive moving average.
> Weather, traffic and port congestion are the main drivers, and you can see that in the feature importance chart."

**Demo moment:** open the *Model performance* and *What drives delays* cards, then open `/docs` and call `POST /predict/delay` for W1 to C04 before and after a storm.

**Likely questions**
* *Why quantile regression?* It gives a range for each prediction, so the optimizer can plan for risk instead of the average.
* *Is the data real?* It is synthetic, built to match the patterns of the public freight datasets. The pipeline accepts real data, and swapping it in is one function call (see README).
* *How do you know P90 is right?* We measure coverage on held-out data: 89.5% against a 90% target.

---

## Member 2: Optimization Engine and Backend ("the decision maker")

**Files:** `backend/app/optimizer.py`, `inventory.py`, `main.py`

**What you built**
* A **multi-depot vehicle routing solver** (Google OR-Tools) with vehicle capacity and delivery deadlines.
* **Uncertainty-aware planning:** the solver uses `free-flow + P50 + 0.5 x (P90 - P50)` as travel time, so risky links look longer.
* A **Monte-Carlo scorer** that samples random delays 1,500 times per plan and reports each stop's probability of being on time.
* **Automatic re-routing** when a disruption is injected, and **inventory recommendations** (safety stock, reorder point, order quantity) that use the predicted lead-time spread.
* The FastAPI backend that exposes all of it.

**Say this (about 60 seconds)**
> "A normal planner assumes free-flow travel times. Ours plans with the predicted delay range, so it routes around risky links and serves tight-deadline stops first.
> We score every plan with a simulation of random delays. In normal conditions, SmartChain reaches about 94% on-time versus 87% for the free-flow planner.
> When a storm hits Chennai Port, the old plan drops to about 81%. SmartChain re-plans automatically and recovers to about 90%, for roughly 2% more distance.
> The same predictions drive inventory: the storm lengthens the lead time at Chennai DC, so its reorder point jumps from about 2,900 to about 4,900 units and the system raises a critical alert."

**Demo moment:** click **Storm at Chennai Port** and walk through the *Impact* card (before, old plan, SmartChain re-plan).

**Likely questions**
* *Why not just use the P90 time on every leg?* Summing per-leg P90s overestimates the total, so we blend P50 and P90 with a risk-aversion factor (`LAMBDA` in `optimizer.py`) and then verify with simulation.
* *How fast is it?* About 2.5 seconds per plan for 16 stops and 9 vehicles; the time limit is configurable.
* *Does it scale?* OR-Tools handles hundreds of stops with a longer time limit. For very large problems you would add clustering first.
* *Is the improvement real?* It is measured in simulation against our delay model. It shows the method works; field validation would need real delivery logs.

---

## Member 3: Dashboard, Integration and Demo ("what the manager sees")

**Files:** `frontend/index.html`, `style.css`, `app.js`, `README.md`, `docs/`

**What you built**
* A live map where every route segment is coloured by late-delivery risk (green, amber, and red-dashed so it also works without colour).
* KPI cards (on-time %, average lateness, distance, warehouses needing stock action) with comparison against the baseline.
* A **what-if simulator**, a shipment risk table, inventory alerts with order recommendations, a demand-forecast chart, and a model-performance panel.
* Integration of all three parts through the REST APIs, plus the demo flow.

**Say this (about 60 seconds)**
> "This is what a logistics manager would use. The map shows each route coloured by how likely it is to arrive on time. The table ranks shipments by risk.
> The inventory panel tells them which warehouse will run short and how much to order. And the what-if button lets them test a disruption
> before it happens, then see the re-planned routes instantly. Everything on this screen is driven by the live APIs from the backend."

**Demo moment:** you drive the demo (script below).

**Likely questions**
* *Why plain JavaScript instead of React?* There is no build step, so it runs anywhere in a minute. The dashboard only consumes the REST API, so it can be rebuilt in React without touching the backend.
* *What would you add next?* Live weather and traffic feeds, real road distances (OSRM), driver-hours rules, and a PostgreSQL store.

---

## 3-minute demo script

| Time | Who | What happens |
|---|---|---|
| 0:00 | Member 3 | State the problem: delays from traffic, weather and port congestion. Show the dashboard in normal conditions and the SmartChain vs baseline KPIs. |
| 0:40 | Member 1 | Show the *Model performance* card. Explain the delay range (P50/P90) and the 0.91 AUC. Open the demand forecast chart. |
| 1:20 | Member 2 | Explain how the optimizer uses the delay range. Toggle SmartChain / Free-flow baseline on the map. |
| 1:50 | Member 3 | Click **Storm at Chennai Port**. Routes turn red and dashed, circles appear on the map. |
| 2:10 | Member 2 | Read the *Impact* card: old plan falls, SmartChain re-plan recovers. Mention routes changed automatically. |
| 2:30 | Member 1 | Point at the inventory alert: lead time grew, reorder point rose, Chennai DC is critical. |
| 2:45 | Member 3 | **Reset conditions**, summarize: predict, then optimize, then act, even under uncertainty. |

**Tip:** do one full run-through before presenting, so the first click is warm. Press *Reset conditions* between rehearsals.
