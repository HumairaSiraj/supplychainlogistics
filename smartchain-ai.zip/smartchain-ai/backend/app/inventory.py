"""Inventory recommendations driven by the demand forecast AND the predicted inbound delay.

safety stock  = z * sqrt( LT * sigma_d^2  +  mu^2 * sigma_LT^2 )
reorder point = mu * LT + safety stock
where mu / sigma_d = forecast daily demand mean / std and LT = lead time in days:

    LT = base lead time + predicted inland delay (ML model, P50)
         + port dwell time (rises with port congestion)

sigma_LT comes from the spread between the P50 and P90 predictions (inland delay and
port dwell).  A storm or congested port therefore raises the reorder point
automatically.  The port dwell formula is a simple documented heuristic - replace it with
real container-dwell data if you have it.
"""
import math

from .network import NODE_BY_ID, WAREHOUSES

Z_SERVICE = 1.645              # 95 % service level
BASE_LEAD_TIME_DAYS = 3.0      # port -> warehouse plus handling, in normal conditions
REVIEW_DAYS = 7
CURRENT_STOCK = {"W1": 4300, "W2": 3900, "W3": 2900}   # demo stock levels (units on hand)


def port_dwell_days(congestion: float):
    """(median, P90) days that cargo waits at the port as a function of congestion 0..1."""
    return 0.25 + 2.0 * congestion, 0.5 + 4.0 * congestion


def recommend(predictor, state, horizon=14):
    out = []
    for w in WAREHOUSES:
        fc = predictor.demand_forecast(w.id, horizon)
        daily = [f["units"] for f in fc]
        mu = sum(daily) / len(daily)
        sigma_d = predictor.demand_sigma(w.id)

        leg = predictor.predict_leg(w.inbound_port, w.id, state)
        dwell50, dwell90 = port_dwell_days(state.port[w.inbound_port])
        d50 = leg["delay_p50_hours"] / 24 + dwell50
        d90 = leg["delay_p90_hours"] / 24 + dwell90
        lt_mean = BASE_LEAD_TIME_DAYS + d50
        lt_std = max(d90 - d50, 0.0) / 1.2816

        safety = Z_SERVICE * math.sqrt(lt_mean * sigma_d ** 2 + (mu * lt_std) ** 2)
        rop = mu * lt_mean + safety
        stock = CURRENT_STOCK[w.id]
        cover = stock / mu

        # day (fractional) on which cumulative forecast demand exceeds the stock on hand
        cum, stockout_day = 0.0, None
        for k, v in enumerate(daily, start=1):
            if cum + v > stock:
                stockout_day = (k - 1) + (stock - cum) / v
                break
            cum += v

        worst_lt = BASE_LEAD_TIME_DAYS + d90
        if stockout_day is not None and stockout_day <= worst_lt:
            status = "critical"          # stock runs out before a new order could arrive, even in the P90 case
        elif stock <= rop:
            status = "reorder"
        elif stock <= rop * 1.25:
            status = "watch"
        else:
            status = "ok"

        order_up_to = rop + mu * REVIEW_DAYS
        qty = max(0, math.ceil((order_up_to - stock) / 50) * 50)
        out.append({
            "warehouse": w.id, "name": w.name,
            "inbound_port": NODE_BY_ID[w.inbound_port].name,
            "stock": stock,
            "avg_daily_demand": round(mu, 1),
            "days_of_cover": round(cover, 1),
            "lead_time_days": round(lt_mean, 2),
            "lead_time_p90_days": round(worst_lt, 2),
            "port_congestion": round(state.port[w.inbound_port], 2),
            "inbound_prob_late": leg["prob_late"],
            "safety_stock": round(safety),
            "reorder_point": round(rop),
            "recommended_order_qty": qty if status != "ok" else 0,
            "stockout_in_days": round(stockout_day, 1) if stockout_day is not None else None,
            "status": status,
            "forecast": fc,
        })
    return out
