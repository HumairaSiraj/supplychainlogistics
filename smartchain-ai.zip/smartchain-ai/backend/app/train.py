"""Train all models.  Run:  python -m app.train

Models produced (saved in backend/models/):
  delay_clf.joblib   XGBoost classifier   -> P(shipment leg is late)
  delay_p50.joblib   XGBoost quantile reg -> median delay (hours)
  delay_p90.joblib   XGBoost quantile reg -> 90th-percentile delay (hours)   <- uncertainty
  demand.joblib      XGBoost regressor    -> next-day demand ratio (recursive forecast)
  metrics.json       accuracy table + feature importance for the demo
"""
import json
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, f1_score, mean_absolute_error,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier, XGBRegressor

from .common import DATA_DIR, DELAY_FEATURES, LATE_THRESHOLD_H, MODEL_DIR
from .data_gen import generate_demand, generate_shipments
from .forecasting import DEMAND_FEATURES, build_training_frame, forecast

COMMON = dict(n_estimators=300, max_depth=5, learning_rate=0.06, subsample=0.9,
              colsample_bytree=0.9, tree_method="hist", n_jobs=2, random_state=0)


def _pinball(y, pred, alpha):
    d = y - pred
    return float(np.mean(np.maximum(alpha * d, (alpha - 1) * d)))


def train_delay_models(df: pd.DataFrame):
    X, y_delay, y_late = df[DELAY_FEATURES], df["delay_hours"], df["is_late"]
    Xtr, Xte, dtr, dte, ltr, lte = train_test_split(X, y_delay, y_late, test_size=0.2, random_state=1)

    clf = XGBClassifier(**{**COMMON, "n_estimators": 250}, eval_metric="logloss")
    clf.fit(Xtr, ltr)
    prob = clf.predict_proba(Xte)[:, 1]
    pred = (prob >= 0.5).astype(int)

    # Quantile regression on log(1+delay): quantiles are preserved under monotone transforms
    q50 = XGBRegressor(**COMMON, objective="reg:quantileerror", quantile_alpha=0.5)
    q90 = XGBRegressor(**COMMON, objective="reg:quantileerror", quantile_alpha=0.9)
    q50.fit(Xtr, np.log1p(dtr))
    q90.fit(Xtr, np.log1p(dtr))
    p50 = np.expm1(q50.predict(Xte))
    p90 = np.maximum(np.expm1(q90.predict(Xte)), p50)

    metrics = {
        "delay_classifier": {
            "accuracy": round(accuracy_score(lte, pred), 4),
            "precision": round(precision_score(lte, pred), 4),
            "recall": round(recall_score(lte, pred), 4),
            "f1": round(f1_score(lte, pred), 4),
            "roc_auc": round(roc_auc_score(lte, prob), 4),
            "late_rate": round(float(lte.mean()), 4),
            "late_threshold_hours": LATE_THRESHOLD_H,
            "n_train": int(len(Xtr)),
            "n_test": int(len(Xte)),
        },
        "delay_p50": {
            "mae_hours": round(mean_absolute_error(dte, p50), 4),
            "baseline_mae_hours": round(mean_absolute_error(dte, np.full(len(dte), dtr.median())), 4),
        },
        "delay_p90": {
            "coverage": round(float((dte.values <= p90).mean()), 4),
            "target_coverage": 0.9,
            "pinball_loss": round(_pinball(dte.values, p90, 0.9), 4),
        },
    }
    imp = dict(zip(DELAY_FEATURES, clf.feature_importances_.tolist()))
    metrics["feature_importance"] = {k: round(v, 4) for k, v in sorted(imp.items(), key=lambda kv: -kv[1])}
    return clf, q50, q90, metrics


def train_demand_model(demand_df: pd.DataFrame):
    frame = build_training_frame(demand_df)
    cutoff = frame["date"].max() - pd.Timedelta(days=60)
    train, test = frame[frame["date"] <= cutoff], frame[frame["date"] > cutoff]

    model = XGBRegressor(n_estimators=250, max_depth=4, learning_rate=0.05, subsample=0.9,
                         colsample_bytree=0.9, tree_method="hist", n_jobs=2, random_state=0)
    model.fit(train[DEMAND_FEATURES], train["units"] / train["roll28"])

    one_step = model.predict(test[DEMAND_FEATURES]) * test["roll28"].values
    actual = test["units"].values
    mape1 = float(np.mean(np.abs(one_step - actual) / actual) * 100)
    naive = test["roll28"].values
    mape_naive = float(np.mean(np.abs(naive - actual) / actual) * 100)

    # 7-day recursive forecast evaluated on non-overlapping blocks of the hold-out period
    errs, resid_std = [], {}
    for wid, g in demand_df.groupby("warehouse"):
        g = g.sort_values("date").reset_index(drop=True)
        vals = g["units"].tolist()
        n = len(vals)
        for start in range(n - 56, n - 7, 7):
            hist = vals[:start]
            fc = forecast(model, hist, g["date"].iloc[start - 1], wid, 7)
            truth = vals[start:start + 7]
            errs.extend([abs(f["units"] - t) / t for f, t in zip(fc, truth)])
        resid = (one_step - actual)[test["warehouse"].values == wid]
        resid_std[wid] = round(float(np.std(resid)), 2)

    metrics = {
        "mape_one_step_pct": round(mape1, 2),
        "mape_naive_pct": round(mape_naive, 2),
        "mape_7day_recursive_pct": round(float(np.mean(errs) * 100), 2),
        "holdout_days": 60,
        "residual_std_units": resid_std,
    }
    return model, metrics


def train_all(shipments: pd.DataFrame | None = None, verbose: bool = True):
    t0 = time.time()
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    shipments = shipments if shipments is not None else generate_shipments()
    demand_df = generate_demand()
    shipments.to_csv(DATA_DIR / "shipments.csv", index=False)
    demand_df.to_csv(DATA_DIR / "demand_history.csv", index=False)

    clf, q50, q90, m_delay = train_delay_models(shipments)
    dmodel, m_demand = train_demand_model(demand_df)

    joblib.dump(clf, MODEL_DIR / "delay_clf.joblib")
    joblib.dump(q50, MODEL_DIR / "delay_p50.joblib")
    joblib.dump(q90, MODEL_DIR / "delay_p90.joblib")
    joblib.dump(dmodel, MODEL_DIR / "demand.joblib")

    metrics = {**m_delay, "demand": m_demand, "train_seconds": round(time.time() - t0, 1),
               "training_rows": int(len(shipments))}
    (MODEL_DIR / "metrics.json").write_text(json.dumps(metrics, indent=2))
    if verbose:
        print(json.dumps(metrics, indent=2))
    return metrics


if __name__ == "__main__":
    train_all()
