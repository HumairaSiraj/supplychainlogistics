"""Loads the trained models and turns operating conditions into predictions."""
import json
from dataclasses import dataclass

import joblib
import numpy as np
import pandas as pd

from .common import DATA_DIR, DELAY_FEATURES, MODEL_DIR, MODES, planned_hours
from .forecasting import forecast
from .network import NODES, NODE_BY_ID, road_km


@dataclass
class Matrix:
    """All-pairs predictions between every node for one set of conditions (hours / km)."""
    ids: list
    idx: dict
    km: np.ndarray
    base_h: np.ndarray    # free-flow travel time
    p50: np.ndarray       # median delay
    p90: np.ndarray       # 90th percentile delay (risk)
    p_late: np.ndarray    # probability the leg is late


class Predictor:
    def __init__(self):
        self.clf = joblib.load(MODEL_DIR / "delay_clf.joblib")
        self.q50 = joblib.load(MODEL_DIR / "delay_p50.joblib")
        self.q90 = joblib.load(MODEL_DIR / "delay_p90.joblib")
        self.demand_model = joblib.load(MODEL_DIR / "demand.joblib")
        self.metrics = json.loads((MODEL_DIR / "metrics.json").read_text())
        hist = pd.read_csv(DATA_DIR / "demand_history.csv", parse_dates=["date"])
        self.history = {w: g.sort_values("date") for w, g in hist.groupby("warehouse")}
        self._cache = {}

    @classmethod
    def load_or_train(cls):
        needed = ["delay_clf", "delay_p50", "delay_p90", "demand"]
        if not all((MODEL_DIR / f"{n}.joblib").exists() for n in needed) or not (DATA_DIR / "demand_history.csv").exists():
            from .train import train_all
            print("Models not found - training (about 30-60 seconds)...")
            train_all(verbose=False)
        return cls()

    # ---------- delay -------------------------------------------------------------
    def predict_frame(self, df: pd.DataFrame) -> pd.DataFrame:
        X = df[DELAY_FEATURES]
        p_late = self.clf.predict_proba(X)[:, 1]
        p50 = np.maximum(np.expm1(self.q50.predict(X)), 0.0)
        p90 = np.maximum(np.expm1(self.q90.predict(X)), p50)
        return pd.DataFrame({"p_late": p_late, "p50": p50, "p90": p90}, index=df.index)

    @staticmethod
    def _leg_row(a, b, state, mode=0):
        dist = road_km(a, b)
        return {
            "distance_km": dist,
            "mode": mode,
            "planned_hours": float(planned_hours(dist, mode)),
            "weather": (state.weather[a.id] + state.weather[b.id]) / 2,
            "traffic": (state.traffic[a.id] + state.traffic[b.id]) / 2,
            "port_congestion": max(state.port[a.port], state.port[b.port]),
            "hour": state.hour,
            "dow": state.dow,
            "month": state.month,
        }

    def predict_leg(self, origin: str, destination: str, state, mode: str = "road") -> dict:
        a, b = NODE_BY_ID[origin], NODE_BY_ID[destination]
        row = self._leg_row(a, b, state, MODES[mode])
        out = self.predict_frame(pd.DataFrame([row])).iloc[0]
        return {
            "origin": a.name,
            "destination": b.name,
            "mode": mode,
            "distance_km": round(row["distance_km"], 1),
            "planned_hours": round(row["planned_hours"], 2),
            "conditions": {
                "weather": round(row["weather"], 2),
                "traffic": round(row["traffic"], 2),
                "port_congestion": round(row["port_congestion"], 2),
            },
            "prob_late": round(float(out.p_late), 3),
            "delay_p50_hours": round(float(out.p50), 2),
            "delay_p90_hours": round(float(out.p90), 2),
            "expected_travel_hours_p50": round(row["planned_hours"] + float(out.p50), 2),
            "expected_travel_hours_p90": round(row["planned_hours"] + float(out.p90), 2),
        }

    def matrix(self, state) -> Matrix:
        if state.version in self._cache:
            return self._cache[state.version]
        ids = [n.id for n in NODES]
        n = len(ids)
        rows, pairs = [], []
        for i, a in enumerate(NODES):
            for j, b in enumerate(NODES):
                if i != j:
                    rows.append(self._leg_row(a, b, state))
                    pairs.append((i, j))
        pred = self.predict_frame(pd.DataFrame(rows))
        km = np.zeros((n, n)); base = np.zeros((n, n))
        p50 = np.zeros((n, n)); p90 = np.zeros((n, n)); pl = np.zeros((n, n))
        for k, (i, j) in enumerate(pairs):
            km[i, j] = rows[k]["distance_km"]
            base[i, j] = rows[k]["planned_hours"]
            p50[i, j] = pred["p50"].iat[k]
            p90[i, j] = pred["p90"].iat[k]
            pl[i, j] = pred["p_late"].iat[k]
        m = Matrix(ids, {x: i for i, x in enumerate(ids)}, km, base, p50, p90, pl)
        self._cache = {state.version: m}       # keep only the latest
        return m

    # ---------- demand ------------------------------------------------------------
    def demand_forecast(self, warehouse: str, days: int = 14) -> list:
        g = self.history[warehouse]
        return forecast(self.demand_model, g["units"].tolist(), g["date"].iloc[-1], warehouse, days)

    def demand_history(self, warehouse: str, days: int = 30) -> list:
        g = self.history[warehouse].tail(days)
        return [{"date": d.date().isoformat(), "units": float(u)} for d, u in zip(g["date"], g["units"])]

    def demand_sigma(self, warehouse: str) -> float:
        return float(self.metrics["demand"]["residual_std_units"][warehouse])
