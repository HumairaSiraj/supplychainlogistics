"""The logistics network: ports, warehouses (depots) and delivery points.

Coordinates are real South-Indian cities so the map looks right in a demo.
Swap this file for your own network (or load it from PostgreSQL) to reuse the system.
"""
import math
from dataclasses import dataclass, asdict

from .common import ROAD_FACTOR


@dataclass(frozen=True)
class Node:
    id: str
    name: str
    kind: str                 # "port" | "warehouse" | "customer"
    lat: float
    lon: float
    metro: float = 0.3        # baseline traffic level 0..1
    demand: int = 0           # units to deliver today (customers)
    deadline_h: float = 0.0   # delivery deadline in hours after dispatch (customers)
    priority: int = 1         # 1 normal, 2 high
    port: str = ""            # nearest port id (its congestion zone)
    inbound_port: str = ""    # warehouses: the port supplying this warehouse

    def to_dict(self):
        return asdict(self)


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def road_km(a: Node, b: Node) -> float:
    return haversine_km(a.lat, a.lon, b.lat, b.lon) * ROAD_FACTOR


_PORTS = [
    Node("P_CHE", "Chennai Port", "port", 13.10, 80.30, metro=0.5),
    Node("P_VIZ", "Visakhapatnam Port", "port", 17.69, 83.29, metro=0.4),
    Node("P_COK", "Kochi Port", "port", 9.97, 76.27, metro=0.4),
]

_WAREHOUSES = [
    Node("W1", "Chennai DC", "warehouse", 12.99, 80.20, metro=0.55, inbound_port="P_CHE"),
    Node("W2", "Bengaluru DC", "warehouse", 13.00, 77.70, metro=0.70, inbound_port="P_COK"),
    Node("W3", "Hyderabad DC", "warehouse", 17.45, 78.38, metro=0.60, inbound_port="P_VIZ"),
]

# id, name, lat, lon, demand units, deadline hours, priority, metro traffic
_CUSTOMERS = [
    ("C01", "Vellore", 12.92, 79.13, 30, 6.0, 2, 0.25),
    ("C02", "Puducherry", 11.93, 79.83, 35, 7.0, 1, 0.30),
    ("C03", "Tiruchirappalli", 10.79, 78.70, 40, 12.0, 1, 0.30),
    ("C04", "Madurai", 9.93, 78.12, 45, 15.0, 1, 0.35),
    ("C05", "Salem", 11.66, 78.15, 30, 10.0, 1, 0.30),
    ("C06", "Coimbatore", 11.02, 76.96, 50, 12.0, 2, 0.40),
    ("C07", "Tirupati", 13.63, 79.42, 35, 7.0, 1, 0.25),
    ("C08", "Nellore", 14.44, 79.99, 25, 8.0, 1, 0.25),
    ("C09", "Mysuru", 12.30, 76.64, 30, 7.0, 2, 0.30),
    ("C10", "Hosur", 12.74, 77.83, 25, 4.0, 2, 0.45),
    ("C11", "Tumakuru", 13.34, 77.10, 20, 5.0, 1, 0.25),
    ("C12", "Kurnool", 15.83, 78.04, 30, 9.0, 1, 0.25),
    ("C13", "Warangal", 17.97, 79.60, 35, 6.0, 1, 0.30),
    ("C14", "Vijayawada", 16.51, 80.65, 45, 12.0, 2, 0.40),
    ("C15", "Nizamabad", 18.67, 78.09, 25, 7.0, 1, 0.25),
    ("C16", "Anantapur", 14.68, 77.60, 25, 8.0, 1, 0.25),
]


def _nearest_port(lat, lon):
    return min(_PORTS, key=lambda p: haversine_km(lat, lon, p.lat, p.lon)).id


def _build():
    nodes = []
    for p in _PORTS:
        nodes.append(Node(**{**asdict(p), "port": p.id}))
    for w in _WAREHOUSES:
        nodes.append(Node(**{**asdict(w), "port": _nearest_port(w.lat, w.lon)}))
    for cid, name, lat, lon, dem, dl, pr, metro in _CUSTOMERS:
        nodes.append(Node(cid, name, "customer", lat, lon, metro=metro, demand=dem,
                          deadline_h=dl, priority=pr, port=_nearest_port(lat, lon)))
    return nodes


NODES = _build()
NODE_BY_ID = {n.id: n for n in NODES}
PORTS = [n for n in NODES if n.kind == "port"]
WAREHOUSES = [n for n in NODES if n.kind == "warehouse"]
CUSTOMERS = [n for n in NODES if n.kind == "customer"]
