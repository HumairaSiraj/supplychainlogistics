"""FastAPI application: prediction, optimization, inventory and simulation endpoints.

Run:  uvicorn app.main:app --reload --port 8000     (from the backend/ folder)
Docs: http://localhost:8000/docs      Dashboard: http://localhost:8000/
"""
import threading
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import inventory as inv
from .common import FRONTEND_DIR, MODES
from .conditions import ConditionState
from .network import CUSTOMERS, NODES, NODE_BY_ID, PORTS, WAREHOUSES
from .optimizer import evaluate_routes, improvement, solve_plan
from .predictor import Predictor

STATE = ConditionState()
LOCK = threading.RLock()
CTX: dict = {"pred": None, "plan": None, "baseline": {}}   # plan = last SmartChain plan


def baseline_plan(M, demand_scale, time_limit_ms):
    """The free-flow planner ignores conditions, so its plan only depends on demand: cache it."""
    key = (demand_scale, time_limit_ms)
    if key not in CTX["baseline"]:
        CTX["baseline"][key] = solve_plan(M, "baseline", demand_scale, time_limit_ms)
    return CTX["baseline"][key]


@asynccontextmanager
async def lifespan(app: FastAPI):
    CTX["pred"] = Predictor.load_or_train()
    yield


app = FastAPI(title="SmartChain AI", version="1.0.0",
              description="AI-powered supply chain & logistics optimization", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def pred() -> Predictor:
    return CTX["pred"]


# ------------------------------------------------------------------ request models
class DelayRequest(BaseModel):
    origin: str = Field(examples=["W1"])
    destination: str = Field(examples=["C04"])
    mode: Literal["road", "rail", "air"] = "road"


class OptimizeRequest(BaseModel):
    mode: Literal["smart", "baseline"] = "smart"
    demand_scale: float = Field(1.0, ge=0.5, le=1.7)
    time_limit_ms: int = Field(2500, ge=500, le=20000)


class CompareRequest(BaseModel):
    demand_scale: float = Field(1.0, ge=0.5, le=1.7)
    time_limit_ms: int = Field(2500, ge=500, le=20000)


class DisruptionRequest(BaseModel):
    kind: Literal["storm", "port_congestion", "traffic"]
    target: str = Field(examples=["P_CHE"])
    severity: float = Field(0.9, ge=0.1, le=1.0)
    demand_scale: float = Field(1.0, ge=0.5, le=1.7)
    time_limit_ms: int = Field(2500, ge=500, le=20000)


def _strip(plan):  # keep responses light: "raw" is only for internal re-evaluation
    return {k: v for k, v in plan.items() if k != "raw"}


# ------------------------------------------------------------------ meta endpoints
@app.get("/api/health")
def health():
    return {"status": "ok", "models_loaded": pred() is not None}


@app.get("/api/network")
def network():
    return {
        "nodes": [n.to_dict() for n in NODES],
        "warehouses": [n.id for n in WAREHOUSES],
        "ports": [n.id for n in PORTS],
        "customers": [n.id for n in CUSTOMERS],
    }


@app.get("/api/state")
def state():
    return STATE.snapshot()


@app.get("/api/metrics")
def metrics():
    return pred().metrics


# ------------------------------------------------------------------ Part 1: prediction
@app.post("/predict/delay")
def predict_delay(req: DelayRequest):
    if req.origin not in NODE_BY_ID or req.destination not in NODE_BY_ID:
        raise HTTPException(404, "Unknown origin or destination id (see GET /api/network)")
    if req.origin == req.destination:
        raise HTTPException(400, "Origin and destination must differ")
    return pred().predict_leg(req.origin, req.destination, STATE, req.mode)


@app.get("/predict/demand")
def predict_demand(warehouse: str = Query("W1", pattern="^W[1-3]$"), days: int = Query(14, ge=1, le=60)):
    return {
        "warehouse": warehouse,
        "history": pred().demand_history(warehouse, 30),
        "forecast": pred().demand_forecast(warehouse, days),
    }


# ------------------------------------------------------------------ Part 2: optimization
@app.post("/optimize/routes")
def optimize_routes(req: OptimizeRequest):
    with LOCK:
        M = pred().matrix(STATE)
        if req.mode == "baseline":
            raw = baseline_plan(M, req.demand_scale, req.time_limit_ms)["raw"]
            return _strip(evaluate_routes(raw, M, req.demand_scale, "baseline"))
        plan = solve_plan(M, "smart", req.demand_scale, req.time_limit_ms)
        CTX["plan"] = plan
        return _strip(plan)


@app.post("/optimize/compare")
def optimize_compare(req: CompareRequest):
    """Baseline (free-flow) planner vs SmartChain (delay-aware), same conditions."""
    with LOCK:
        M = pred().matrix(STATE)
        base_plan = baseline_plan(M, req.demand_scale, req.time_limit_ms)
        # same routes, scored under the *current* conditions
        base = evaluate_routes(base_plan["raw"], M, req.demand_scale, "baseline")
        smart = solve_plan(M, "smart", req.demand_scale, req.time_limit_ms)
        CTX["plan"] = smart
        return {
            "baseline": _strip(base),
            "smart": _strip(smart),
            "improvement": improvement(base["kpis"], smart["kpis"]),
        }


@app.get("/inventory/recommend")
def inventory_recommend():
    with LOCK:
        items = inv.recommend(pred(), STATE)
    return {"items": items, "at_risk": sum(1 for i in items if i["status"] in ("critical", "reorder"))}


@app.post("/simulate/disruption")
def simulate_disruption(req: DisruptionRequest):
    """Inject a disruption, show what happens to the old plan, then re-plan automatically."""
    with LOCK:
        P = pred()
        M0 = P.matrix(STATE)
        before = CTX["plan"]
        if before is None or before["demand_scale"] != req.demand_scale:
            before = solve_plan(M0, "smart", req.demand_scale, req.time_limit_ms)
        baseline_before = baseline_plan(M0, req.demand_scale, req.time_limit_ms)

        try:
            event = STATE.apply(req.kind, req.target, req.severity)
        except ValueError as e:
            raise HTTPException(400, str(e))

        M1 = P.matrix(STATE)
        stale = evaluate_routes(before["raw"], M1, req.demand_scale)              # old plan, new conditions
        naive = evaluate_routes(baseline_before["raw"], M1, req.demand_scale, "baseline")
        after = solve_plan(M1, "smart", req.demand_scale, req.time_limit_ms)      # automatic re-routing
        CTX["plan"] = after

        drop = before["kpis"]["on_time_pct"] - stale["kpis"]["on_time_pct"]
        return {
            "event": event,
            "triggered_replan": drop > 5.0,
            "before_kpis": before["kpis"],
            "no_replan_kpis": stale["kpis"],
            "baseline_planner_kpis": naive["kpis"],
            "after": _strip(after),
            "baseline_after": _strip(naive),
            "improvement": improvement(naive["kpis"], after["kpis"]),
            "recovered_points": round(after["kpis"]["on_time_pct"] - stale["kpis"]["on_time_pct"], 1),
            "routes_changed": before["raw"] != after["raw"],
        }


@app.post("/simulate/reset")
def simulate_reset():
    with LOCK:
        STATE.reset()
        CTX["plan"] = None
    return {"status": "reset"}


# ------------------------------------------------------------------ dashboard (Part 3)
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
