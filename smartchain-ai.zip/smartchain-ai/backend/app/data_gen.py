"""Synthetic-but-realistic training data.

Why synthetic?  The public datasets named in the problem statement (DataCo Smart
Supply Chain, BTS Freight Analysis Framework, World Bank LPI) have different schemas
and need manual download.  This generator reproduces the same *relationships* those
datasets show (delay grows with distance, bad weather, congested ports, peak-hour
traffic, and the spread of delays grows in bad conditions) so the full pipeline runs
anywhere.  To use real data, produce a DataFrame with the columns in
``common.DELAY_FEATURES`` + ``delay_hours`` and pass it to ``train.train_all``.
"""
from datetime import date, timedelta

import numpy as np
import pandas as pd

from .common import LATE_THRESHOLD_H, planned_hours


def generate_shipments(n: int = 30000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    distance = np.clip(rng.gamma(2.2, 160.0, n), 15, 1400)
    mode = rng.choice([0, 1, 2], size=n, p=[0.72, 0.20, 0.08])

    storm_day = rng.random(n) < 0.15
    weather = np.where(storm_day, rng.beta(5, 2, n), rng.beta(1.3, 7, n))
    traffic = rng.beta(2.0, 3.5, n)
    port_hot = rng.random(n) < 0.12
    port = np.where(port_hot, rng.beta(6, 2, n), rng.beta(2, 5, n))

    hour = rng.integers(0, 24, n)
    dow = rng.integers(0, 7, n)
    month = rng.integers(1, 13, n)

    plan_h = planned_hours(distance, mode)
    peak = ((hour >= 7) & (hour <= 10)) | ((hour >= 17) & (hour <= 21))
    monsoon = np.isin(month, [6, 7, 8, 9, 10, 11]).astype(float)

    severity = (
        0.35
        + 2.2 * weather
        + 1.3 * traffic * (mode == 0)
        + 0.5 * traffic * peak
        + 1.8 * port
        + 0.25 * monsoon
    )
    sigma = 0.25 + 0.6 * weather + 0.3 * port           # delays get *less predictable* in bad conditions
    median_delay = plan_h * 0.06 * severity
    delay = median_delay * rng.lognormal(0.0, sigma)

    df = pd.DataFrame(
        {
            "distance_km": distance.round(1),
            "mode": mode,
            "planned_hours": plan_h.round(3),
            "weather": weather.round(3),
            "traffic": traffic.round(3),
            "port_congestion": port.round(3),
            "hour": hour,
            "dow": dow,
            "month": month,
            "delay_hours": delay.round(3),
        }
    )
    df["is_late"] = (df["delay_hours"] > LATE_THRESHOLD_H).astype(int)
    return df


WAREHOUSE_BASE = {"W1": 420.0, "W2": 380.0, "W3": 350.0}


def generate_demand(days: int = 900, seed: int = 11) -> pd.DataFrame:
    """Daily demand per warehouse with trend, weekly + yearly seasonality and a festival peak."""
    rng = np.random.default_rng(seed)
    end = date.today() - timedelta(days=1)
    dates = pd.date_range(end=end, periods=days)
    weekly = np.array([1.10, 1.10, 1.05, 1.05, 1.00, 0.80, 0.70])  # Mon..Sun
    rows = []
    for i, (wid, base) in enumerate(WAREHOUSE_BASE.items()):
        t = np.arange(days)
        doy = dates.dayofyear.values
        trend = 1 + 0.0003 * t
        yearly = 1 + 0.12 * np.sin(2 * np.pi * doy / 365 + i)
        festival = 1 + 0.30 * np.exp(-((doy - 305) ** 2) / (2 * 18 ** 2))   # Diwali season bump
        noise = rng.lognormal(0, 0.07, days)
        units = base * trend * yearly * festival * weekly[dates.dayofweek.values] * noise
        rows.append(pd.DataFrame({"date": dates, "warehouse": wid, "units": units.round(1)}))
    return pd.concat(rows, ignore_index=True)
