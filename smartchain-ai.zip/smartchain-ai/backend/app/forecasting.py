"""Demand forecasting with XGBoost on lag features (recursive multi-step)."""
from datetime import timedelta

import numpy as np
import pandas as pd

WID = {"W1": 0, "W2": 1, "W3": 2}
DEMAND_FEATURES = ["wid", "dow", "month", "doy", "lag1_r", "lag7_r", "roll7_r"]


def _row(hist, day, wid):
    """Feature row for predicting the demand on `day` given the history list."""
    roll28 = float(np.mean(hist[-28:]))
    return roll28, {
        "wid": WID[wid],
        "dow": day.weekday(),
        "month": day.month,
        "doy": day.timetuple().tm_yday,
        "lag1_r": hist[-1] / roll28,
        "lag7_r": hist[-7] / roll28,
        "roll7_r": float(np.mean(hist[-7:])) / roll28,
    }


def build_training_frame(df: pd.DataFrame) -> pd.DataFrame:
    parts = []
    for wid, g in df.groupby("warehouse"):
        g = g.sort_values("date").reset_index(drop=True)
        u = g["units"]
        roll28 = u.shift(1).rolling(28).mean()
        out = pd.DataFrame(
            {
                "date": g["date"],
                "warehouse": wid,
                "wid": WID[wid],
                "dow": g["date"].dt.dayofweek,
                "month": g["date"].dt.month,
                "doy": g["date"].dt.dayofyear,
                "lag1_r": u.shift(1) / roll28,
                "lag7_r": u.shift(7) / roll28,
                "roll7_r": u.shift(1).rolling(7).mean() / roll28,
                "roll28": roll28,
                "units": u,
            }
        )
        parts.append(out.dropna())
    return pd.concat(parts, ignore_index=True)


def forecast(model, history, last_date, wid, horizon):
    """Recursive forecast. `history` is a list of past daily units ending on `last_date`."""
    hist = list(history)
    out = []
    for k in range(1, horizon + 1):
        day = last_date + timedelta(days=k)
        roll28, feats = _row(hist, day, wid)
        ratio = float(model.predict(pd.DataFrame([feats])[DEMAND_FEATURES])[0])
        val = max(ratio * roll28, 0.0)
        hist.append(val)
        out.append({"date": day.date().isoformat() if hasattr(day, "date") else str(day), "units": round(val, 1)})
    return out
