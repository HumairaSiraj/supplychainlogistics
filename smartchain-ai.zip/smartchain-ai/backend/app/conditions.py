"""Live operating conditions: weather, traffic and port congestion.

In production these values come from APIs (Open-Meteo for weather, a traffic feed,
port congestion data). Here they are a small mutable state so that the what-if
simulator can inject disruptions and the whole system reacts.
"""
import threading
from datetime import datetime

import numpy as np

from .network import NODES, NODE_BY_ID, PORTS, haversine_km

STORM_RADIUS_KM = 350.0
TRAFFIC_RADIUS_KM = 150.0


class ConditionState:
    def __init__(self):
        self._lock = threading.RLock()
        self.reset()

    def reset(self):
        with self._lock:
            rng = np.random.default_rng(7)
            self.weather = {n.id: float(rng.uniform(0.03, 0.18)) for n in NODES}
            self.traffic = {
                n.id: float(np.clip(n.metro + rng.normal(0, 0.04), 0.05, 0.95)) for n in NODES
            }
            self.port = {p.id: float(rng.uniform(0.15, 0.30)) for p in PORTS}
            self.events = []
            self.version = getattr(self, "version", 0) + 1
            now = datetime.now()
            self.hour = 9            # dispatch-day travel window
            self.dow = now.weekday()
            self.month = now.month

    def apply(self, kind: str, target: str, severity: float):
        """Inject a disruption. kind: storm | port_congestion | traffic."""
        if target not in NODE_BY_ID:
            raise ValueError(f"Unknown target '{target}'")
        centre = NODE_BY_ID[target]
        with self._lock:
            if kind == "storm":
                for n in NODES:
                    d = haversine_km(centre.lat, centre.lon, n.lat, n.lon)
                    if d < STORM_RADIUS_KM:
                        level = severity * (1 - 0.6 * d / STORM_RADIUS_KM)
                        self.weather[n.id] = max(self.weather[n.id], level)
                if centre.kind == "port":
                    self.port[centre.id] = max(self.port[centre.id], min(1.0, severity + 0.05))
            elif kind == "port_congestion":
                if centre.kind != "port":
                    raise ValueError("port_congestion needs a port as target")
                self.port[centre.id] = max(self.port[centre.id], severity)
            elif kind == "traffic":
                for n in NODES:
                    d = haversine_km(centre.lat, centre.lon, n.lat, n.lon)
                    if d < TRAFFIC_RADIUS_KM:
                        level = severity * (1 - 0.5 * d / TRAFFIC_RADIUS_KM)
                        self.traffic[n.id] = max(self.traffic[n.id], level)
            else:
                raise ValueError(f"Unknown disruption kind '{kind}'")
            event = {
                "kind": kind,
                "target": target,
                "target_name": centre.name,
                "lat": centre.lat,
                "lon": centre.lon,
                "severity": severity,
                "radius_km": STORM_RADIUS_KM if kind == "storm" else
                (TRAFFIC_RADIUS_KM if kind == "traffic" else 60.0),
            }
            self.events.append(event)
            self.version += 1
            return event

    def snapshot(self):
        with self._lock:
            return {
                "version": self.version,
                "weather": dict(self.weather),
                "traffic": dict(self.traffic),
                "port_congestion": dict(self.port),
                "events": list(self.events),
            }
