"""Shared constants and helpers used by every part of SmartChain AI."""
from pathlib import Path

import numpy as np

BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_DIR = BASE_DIR / "models"
DATA_DIR = BASE_DIR / "data"
FRONTEND_DIR = BASE_DIR.parent / "frontend"

ROAD_FACTOR = 1.25        # road distance = straight-line distance * factor
LATE_THRESHOLD_H = 1.5    # a leg counts as "late" if delayed more than this
SERVICE_H = 0.75          # unloading time at each delivery stop (hours)

MODES = {"road": 0, "rail": 1, "air": 2}

DELAY_FEATURES = [
    "distance_km",
    "mode",
    "planned_hours",
    "weather",
    "traffic",
    "port_congestion",
    "hour",
    "dow",
    "month",
]


def planned_hours(distance_km, mode):
    """Free-flow travel time in hours for a distance and transport mode."""
    d = np.asarray(distance_km, dtype=float)
    m = np.asarray(mode)
    return np.where(m == 0, d / 50.0, np.where(m == 1, d / 40.0 + 2.0, d / 700.0 + 4.0))
