"""Uncertainty-aware route optimization (multi-depot VRP with deadlines) using OR-Tools.

Two planners are compared in the demo:
  baseline : classic planner - assumes free-flow travel times, ignores predicted delays.
  smart    : SmartChain - plans with  base + P50 + lam * (P90 - P50)  travel times, so risky
             links (storm, congested port, traffic) look longer and the solver routes
             around them / serves tight-deadline stops first.

Every plan (either planner, any conditions) is then scored the same way: a Monte-Carlo
simulation draws random delays for every leg from the predicted distribution and
measures the probability that each stop is reached before its deadline.
"""
import numpy as np
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

from .common import SERVICE_H
from .network import CUSTOMERS, NODE_BY_ID, WAREHOUSES

LAMBDA = 0.5              # risk aversion: 0 = plan on median delay, 1 = plan on P90 delay
VEHICLES_PER_DEPOT = 3
CAPACITY = 100            # units per vehicle
HORIZON_MIN = 72 * 60
LATE_COEF = 4             # solver cost per minute of lateness (x stop priority)
FIXED_COST = 200          # solver cost for using a vehicle
RISK_KM = 30              # extra arc cost (km-equivalent) for a leg with p_late = 1
Z90 = 1.2816


# ----------------------------------------------------------------------------------
def solve_plan(M, mode="smart", demand_scale=1.0, time_limit_ms=2500, lam=LAMBDA):
    depots, customers = WAREHOUSES, CUSTOMERS
    n_dep, n_cus = len(depots), len(customers)
    ids = [d.id for d in depots] + [c.id for c in customers]
    ix = np.ix_([M.idx[i] for i in ids], [M.idx[i] for i in ids])
    km, base, p50, p90, pl = M.km[ix], M.base_h[ix], M.p50[ix], M.p90[ix], M.p_late[ix]

    if mode == "baseline":
        travel_h, risk_w = base, 0.0
    else:
        travel_h, risk_w = base + p50 + lam * (p90 - p50), 1.0

    tmin = np.rint(travel_h * 60).astype(int)
    arc = np.rint(km + risk_w * RISK_KM * pl).astype(int)
    service = [0] * n_dep + [int(SERVICE_H * 60)] * n_cus
    demand = [0] * n_dep + [max(1, int(round(c.demand * demand_scale))) for c in customers]

    n_veh = n_dep * VEHICLES_PER_DEPOT
    starts = [d for d in range(n_dep) for _ in range(VEHICLES_PER_DEPOT)]
    manager = pywrapcp.RoutingIndexManager(len(ids), n_veh, starts, starts)
    routing = pywrapcp.RoutingModel(manager)

    def arc_cb(i, j):
        return int(arc[manager.IndexToNode(i)][manager.IndexToNode(j)])

    def time_cb(i, j):
        a, b = manager.IndexToNode(i), manager.IndexToNode(j)
        return int(tmin[a][b] + service[a])

    def demand_cb(i):
        return demand[manager.IndexToNode(i)]

    arc_idx = routing.RegisterTransitCallback(arc_cb)
    time_idx = routing.RegisterTransitCallback(time_cb)
    dem_idx = routing.RegisterUnaryTransitCallback(demand_cb)
    routing.SetArcCostEvaluatorOfAllVehicles(arc_idx)
    routing.SetFixedCostOfAllVehicles(FIXED_COST)
    routing.AddDimensionWithVehicleCapacity(dem_idx, 0, [CAPACITY] * n_veh, True, "Cap")
    routing.AddDimension(time_idx, 0, HORIZON_MIN, True, "Time")
    time_dim = routing.GetDimensionOrDie("Time")
    for k, c in enumerate(customers):
        index = manager.NodeToIndex(n_dep + k)
        time_dim.SetCumulVarSoftUpperBound(index, int(c.deadline_h * 60), LATE_COEF * c.priority)

    params = pywrapcp.DefaultRoutingSearchParameters()
    params.first_solution_strategy = routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
    params.local_search_metaheuristic = routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
    params.time_limit.FromMilliseconds(int(time_limit_ms))
    solution = routing.SolveWithParameters(params)
    if solution is None:
        raise RuntimeError("Optimizer found no feasible plan")

    routes = []
    for v in range(n_veh):
        index, stops = routing.Start(v), []
        while not routing.IsEnd(index):
            node = manager.IndexToNode(index)
            if node >= n_dep:
                stops.append(ids[node])
            index = solution.Value(routing.NextVar(index))
        if stops:
            routes.append({"vehicle": f"V{len(routes) + 1}", "depot": ids[starts[v]], "stops": stops})
    return evaluate_routes(routes, M, demand_scale, mode=mode)


# ----------------------------------------------------------------------------------
def _risk_label(p_on_time):
    return "low" if p_on_time >= 0.85 else ("medium" if p_on_time >= 0.6 else "high")


def evaluate_routes(routes, M, demand_scale=1.0, mode="smart", n_sims=1500, seed=11):
    """Score fixed routes under the delay distribution implied by matrix M."""
    rng = np.random.default_rng(seed)
    out_routes, probs, late_h = [], [], []
    total_km = 0.0

    for r in routes:
        seq = [r["depot"]] + r["stops"]
        a = [M.idx[x] for x in seq[:-1]]
        b = [M.idx[x] for x in seq[1:]]
        base = M.base_h[a, b]
        med = np.maximum(M.p50[a, b], 0.03)
        hi = np.maximum(M.p90[a, b], med * 1.01)
        sigma = np.log(hi / med) / Z90
        delay = med * np.exp(sigma * rng.standard_normal((n_sims, len(a))))
        service_before = np.array([0.0] + [SERVICE_H] * (len(a) - 1))
        arrival = np.cumsum(base + delay + service_before, axis=1)          # (sims, stops)
        arrival_nom = np.cumsum(base + M.p50[a, b] + service_before)

        km = float(M.km[a, b].sum() + M.km[b[-1], M.idx[r["depot"]]])
        total_km += km
        stops_out, load = [], 0
        for k, sid in enumerate(r["stops"]):
            node = NODE_BY_ID[sid]
            p_on = float((arrival[:, k] <= node.deadline_h).mean())
            lateness = float(np.maximum(arrival[:, k] - node.deadline_h, 0).mean())
            probs.append(p_on)
            late_h.append(lateness)
            qty = max(1, int(round(node.demand * demand_scale)))
            load += qty
            stops_out.append({
                "id": sid, "name": node.name, "lat": node.lat, "lon": node.lon,
                "units": qty, "priority": node.priority, "deadline_h": node.deadline_h,
                "from": seq[k], "from_name": NODE_BY_ID[seq[k]].name,
                "leg_km": round(float(M.km[a[k], b[k]]), 1),
                "leg_prob_late": round(float(M.p_late[a[k], b[k]]), 3),
                "leg_delay_p50_h": round(float(M.p50[a[k], b[k]]), 2),
                "leg_delay_p90_h": round(float(M.p90[a[k], b[k]]), 2),
                "eta_nominal_h": round(float(arrival_nom[k]), 2),
                "eta_p50_h": round(float(np.percentile(arrival[:, k], 50)), 2),
                "eta_p90_h": round(float(np.percentile(arrival[:, k], 90)), 2),
                "on_time_prob": round(p_on, 3),
                "late_risk": round(1 - p_on, 3),
                "risk": _risk_label(p_on),
            })
        depot = NODE_BY_ID[r["depot"]]
        out_routes.append({
            "vehicle": r["vehicle"], "depot": depot.id, "depot_name": depot.name,
            "depot_lat": depot.lat, "depot_lon": depot.lon,
            "load": load, "distance_km": round(km, 1), "stops": stops_out,
        })

    probs_a = np.array(probs)
    kpis = {
        "on_time_pct": round(float(probs_a.mean() * 100), 1),
        "avg_late_hours": round(float(np.mean(late_h)), 2),
        "at_risk_stops": int((probs_a < 0.6).sum()),
        "total_km": round(total_km, 0),
        "vehicles_used": len(out_routes),
        "stops": len(probs),
    }
    return {
        "mode": mode,
        "demand_scale": demand_scale,
        "kpis": kpis,
        "routes": out_routes,
        "raw": [{"vehicle": r["vehicle"], "depot": r["depot"], "stops": list(r["stops"])} for r in routes],
    }


def improvement(base_kpis, smart_kpis):
    b, s = base_kpis, smart_kpis
    pct = lambda old, new: round((old - new) / old * 100, 1) if old else 0.0
    return {
        "on_time_pct_points": round(s["on_time_pct"] - b["on_time_pct"], 1),
        "late_hours_reduction_pct": pct(b["avg_late_hours"], s["avg_late_hours"]),
        "at_risk_stops_reduction": b["at_risk_stops"] - s["at_risk_stops"],
        "distance_change_pct": round((s["total_km"] - b["total_km"]) / b["total_km"] * 100, 1),
    }
